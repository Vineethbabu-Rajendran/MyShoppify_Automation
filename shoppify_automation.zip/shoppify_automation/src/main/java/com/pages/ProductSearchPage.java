package com.pages;

import java.io.IOException;

import org.openqa.selenium.By;

import com.base.BaseClass;

public class ProductSearchPage extends BaseClass {
	
	public AddToCartPage searchProduct() throws IOException {
		
		
		driver.findElement(By.id("search-field")).sendKeys("Black");
		reportStep("Login button Clicked successfully", "Pass");
		return new AddToCartPage();

	}

}
