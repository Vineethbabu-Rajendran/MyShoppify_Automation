package com.pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.Assert;

import com.base.BaseClass;

public class AddToCartPage extends BaseClass {
	
	public AddToCartPage selectProduct() {
		driver.findElement(By.xpath("//a[@id='product-1']")).click();
		Assert.assertTrue(true, "Username enterted successfully");
		return this;
	}

	public AddToCartPage clickAddToCartButton() {
		driver.findElement(By.id("add")).click();
		Assert.assertTrue(true, "Username enterted successfully");
        return this;
	}
	
	public AddToCartPage clickMyCart() throws IOException {
		driver.findElement(By.xpath("//div[@id='minicart']/a[@class='toggle-drawer cart desktop ']")).click();
		Assert.assertTrue(true, "Username enterted successfully");
		reportStep("Click my cart Clicked successfully", "Pass");
		return this;
	}
	
	public void validateAddToCart() {
		String text = driver.findElement(By.linkText("Black heels - S / Red")).getText();
		boolean contains = text.contains("Black");
		if (contains) {
			System.out.println("Product added to cart");
		}
		else {
			System.out.println("Product not added to  cart");
		}
	}
}
