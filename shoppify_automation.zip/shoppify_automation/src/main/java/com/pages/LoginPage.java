package com.pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.Assert;

import com.base.BaseClass;

public class LoginPage extends BaseClass {

	public LoginPage enterUsername(String username) throws IOException {
		driver.findElement(By.id("customer_email")).sendKeys(username);
		Assert.assertTrue(true, "Username enterted successfully");
		reportStep("Username entered successfully", "Pass");
		return this;
	}

	public LoginPage enterPassword(String password) throws IOException {
		driver.findElement(By.id("customer_password")).sendKeys(password);
		Assert.assertTrue(true, "Password enterted successfully");
		reportStep("Password entered successfully", "Pass");
		return this;
	}

	public ProductSearchPage clickLoginButton() throws InterruptedException, IOException {

		driver.findElement(By.xpath("//input[@class='button']")).click();
		Assert.assertTrue(true, "Login button clicked successfully successfully");
		reportStep("Login button Clicked successfully", "Pass");
		return new ProductSearchPage();

	}

}
