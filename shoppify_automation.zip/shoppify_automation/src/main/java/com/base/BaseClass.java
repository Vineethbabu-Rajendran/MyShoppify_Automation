package com.base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.utils.ReadExcel;


public class BaseClass {

	public static ChromeDriver driver;
	public static String filename, testname,testdescription, testAuthor, testCategory;
    public static ExtentReports extent;
    public static ExtentTest test;
	@BeforeMethod
	public void preConditions() {
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--disble-notifications");
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.get("https://sauce-demo.myshopify.com/account/login");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

	}

	@AfterMethod
	public void postConditions() {
		driver.quit();

	}
	
	@DataProvider(name = "fetchdata")
	public String[][] sendData() throws IOException {
		return ReadExcel.readData(filename);

	}
	
	@BeforeSuite
	public void startReport() {
		
				ExtentHtmlReporter reporter=new ExtentHtmlReporter("./Reports/result.html");
	            extent=new ExtentReports();
			    extent.attachReporter(reporter);
	}

	@BeforeClass
	public void testcaseDetails() {
		test = extent.createTest(testname, testdescription);
		test.assignAuthor(testAuthor);
		test.assignCategory(testCategory);

	}
	public int takeSnapshot() throws IOException {
		int randomNumber = (int) (Math.random()*9999999+99999999);
		File source = driver.getScreenshotAs(OutputType.FILE);
		File destination=new File("./Snaps/img"+randomNumber+".png");
		FileUtils.copyFile(source, destination);
	    return randomNumber;
		
	}

	public void reportStep(String msg, String status) throws IOException {
		
		if (status.equalsIgnoreCase("pass")) {
			test.pass(msg, MediaEntityBuilder.createScreenCaptureFromPath(".././Snaps/img"+takeSnapshot()+".png").build());
		}
		
		else if(status.equalsIgnoreCase("fail")) {
			test.fail(msg);
		}
	}
	@AfterSuite
	public void stopReport() {
		extent.flush();

	}

}
