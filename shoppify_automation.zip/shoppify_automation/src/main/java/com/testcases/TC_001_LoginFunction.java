package com.testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.base.BaseClass;
import com.pages.LoginPage;

public class TC_001_LoginFunction extends BaseClass {
	
	@BeforeTest
	public void setValues() {
		filename="Login";
		testname="Login Functionality";
		testdescription="Login with valid data";
		testAuthor="Vineeth";
		testCategory="Smoke";

	}

	@Test(dataProvider = "fetchdata")
	public void runLogin(String uName, String pWord) throws InterruptedException, IOException {
		LoginPage lp = new LoginPage();
		lp.enterUsername(uName)
		.enterPassword(pWord)
		.clickLoginButton();
	}

}
