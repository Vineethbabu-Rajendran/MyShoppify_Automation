package com.testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.base.BaseClass;
import com.pages.LoginPage;

public class TC_003_AddToCartFunction extends BaseClass {
	
	@BeforeTest
	public void setValues() {
		filename="Login";
		testname="Add to cart Functionality";
		testdescription="Add to cart Functionality";
		testAuthor="Vineeth";
		testCategory="Smoke";

	}

	@Test(dataProvider = "fetchdata")
	public void runAddToCart(String uName, String pWord) throws InterruptedException, IOException {
		LoginPage lp = new LoginPage();
		lp.enterUsername(uName)
		.enterPassword(pWord)
		.clickLoginButton()
		.searchProduct()
		.clickAddToCartButton()
		.validateAddToCart();
		
		
	}

}
