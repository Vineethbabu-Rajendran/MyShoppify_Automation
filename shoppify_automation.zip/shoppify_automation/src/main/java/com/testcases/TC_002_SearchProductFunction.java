package com.testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.base.BaseClass;
import com.pages.LoginPage;

public class TC_002_SearchProductFunction extends BaseClass {
	
	@BeforeTest
	public void setValues() {
		filename="Login";
		testname="Search Product Functionality";
		testdescription="Search Product Functionality";
		testAuthor="Vineeth";
		testCategory="Smoke";

	}

	@Test(dataProvider = "fetchdata")
	public void runSearchProduct(String uName, String pWord) throws InterruptedException, IOException {
		LoginPage lp = new LoginPage();
		lp.enterUsername(uName)
		.enterPassword(pWord)
		.clickLoginButton()
		.searchProduct();
		
	}

}
